
// after watching a video on react...I decided put my 'css' style in a JS format
export const styles = {
    primaryButton: '#006666',
    hoverOverButton: 'gray',
    borderForButton: '#00000093',
    textForButton: '#FFFFFF',
    textShadow: 'black 2px 2px',
    bet1Color: '#FFFFFF',
    bet5Color: '#8B0000',
    bet10Color: '#00008B',
    bet25Color: '#008000',
    bet50Color: '#FFA500',
    bet100Color: '#FFC0CB',
    bet500Color: '#800080',    
    disabled: '#9aa3a9',
    color: 'black'
}